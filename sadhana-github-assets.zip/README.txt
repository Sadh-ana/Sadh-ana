Sadhana GitHub profile visual assets

Files:
- banner.png: 1600 x 500 profile README banner
- evolve-now.png: 1200 x 630 concept artwork for Evolve Now
- synaptic.png: 1200 x 630 concept artwork for Synaptic
- playworlds.png: 1200 x 630 concept artwork for PlayWorlds

These project images are branded concept artwork, not screenshots of the deployed apps.
Upload banner.png to the root of the Sadh-ana profile repository.
Upload the three project images to an assets/ folder in that repository.
